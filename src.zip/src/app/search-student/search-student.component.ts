import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
  searchQuery: string = '';
  students: any[] = []; // This should be replaced with your student data
  allStudents: any[] = [
    // Sample data for testing
    { id: 1, name: 'John Doe', age: 20, class: 'CS101', phoneNumber: '123-456-7890' },
    { id: 2, name: 'Jane Smith', age: 22, class: 'CS102', phoneNumber: '987-654-3210' },
    // Add more students here
  ];

  constructor(private router: Router) { }

  ngOnInit(): void {
    // Initially, display all students
    this.students = [...this.allStudents];
  }

  onSearch(): void {
    // Filter students based on the search query
    if (this.searchQuery.trim() === '') {
      this.students = [...this.allStudents]; // Reset to all students if the search query is empty
    } else {
      this.students = this.allStudents.filter(student =>
        student.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  }

  onEdit(studentId: number): void {
    // Navigate to the Edit Student page
    this.router.navigate(['/edit', studentId]);
  }
}
