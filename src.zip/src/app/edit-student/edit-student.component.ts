import { Component, OnInit } from '@angular/core';
import { StudentService, Student } from '../student.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css']
})
export class EditStudentComponent implements OnInit {
  student: Student | undefined;

  constructor(
    private studentService: StudentService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.studentService.getStudent(id).subscribe(student => {
      this.student = student;
    });
  }

  onSubmit(): void {
    if (this.student) {
      this.studentService.updateStudent(this.student.id, this.student);
      this.router.navigate(['/students']);
    }
  }
}
