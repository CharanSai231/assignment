import { Component } from '@angular/core';
import { StudentService, Student } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent {
  newStudent: Student = { id: 0, name: '', age: 2, class: '', phone: '' };

  constructor(private studentService: StudentService, private router: Router) {}

  onSubmit(): void {
    this.newStudent.id = Math.floor(Math.random() * 10000); // Generate random ID for simplicity
    this.studentService.addStudent(this.newStudent);
    this.router.navigate(['/students']);
  }
}
